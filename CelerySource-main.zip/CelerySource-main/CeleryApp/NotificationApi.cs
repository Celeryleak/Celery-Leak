﻿// Decompiled with JetBrains decompiler
// Type: CeleryApp.NotificationApi
// Assembly: CeleryApp, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C2BCA464-2E77-4DEE-B9BF-40F89C268B00
// Assembly location: C:\Users\brady\Downloads\Celery\CeleryApp.exe

namespace CeleryApp
{
  internal class NotificationApi : MainWindow
  {
  }
}
