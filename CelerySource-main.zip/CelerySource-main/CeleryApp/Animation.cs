﻿// Decompiled with JetBrains decompiler
// Type: CeleryApp.Animation
// Assembly: CeleryApp, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C2BCA464-2E77-4DEE-B9BF-40F89C268B00
// Assembly location: C:\Users\brady\Downloads\Celery\CeleryApp.exe

using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace CeleryApp
{
  internal class Animation
  {
    private Storyboard Storyboard;

    public async void MoveAnimation(DependencyObject Object, Thickness Get, Thickness Set)
    {
      ThicknessAnimation thicknessAnimation = new ThicknessAnimation();
      thicknessAnimation.From = new Thickness?(Get);
      thicknessAnimation.To = new Thickness?(Set);
      thicknessAnimation.Duration = (Duration) TimeSpan.FromMilliseconds(1000.0);
      thicknessAnimation.EasingFunction = this.Easing;
      ThicknessAnimation Animation = thicknessAnimation;
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) FrameworkElement.MarginProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(100);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (ThicknessAnimation) null;
    }

    public async void TimedMoveAnimation(
      DependencyObject Object,
      Thickness Get,
      Thickness Set,
      double Time)
    {
      ThicknessAnimation thicknessAnimation = new ThicknessAnimation();
      thicknessAnimation.From = new Thickness?(Get);
      thicknessAnimation.To = new Thickness?(Set);
      thicknessAnimation.Duration = (Duration) TimeSpan.FromMilliseconds(Time);
      thicknessAnimation.EasingFunction = this.Easing;
      ThicknessAnimation Animation = thicknessAnimation;
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) FrameworkElement.MarginProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(100);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (ThicknessAnimation) null;
    }

    public async void WidthAnimation(DependencyObject Object, double Set)
    {
      DoubleAnimation Animation = new DoubleAnimation();
      Animation.EasingFunction = this.Easing;
      Animation.To = new double?(Set);
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) FrameworkElement.WidthProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(1000);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (DoubleAnimation) null;
    }

    public async void HeightAnimation(DependencyObject Object, double Set)
    {
      DoubleAnimation Animation = new DoubleAnimation();
      Animation.EasingFunction = this.Easing;
      Animation.To = new double?(Set);
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) FrameworkElement.HeightProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(1000);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (DoubleAnimation) null;
    }

    public async void OpacityAnimation(
      DependencyObject Object,
      double Get,
      double Set,
      double Duration)
    {
      DoubleAnimation Animation = new DoubleAnimation();
      Animation.EasingFunction = this.Easing;
      Animation.Duration = (Duration) TimeSpan.FromMilliseconds(Duration);
      Animation.From = new double?(Get);
      Animation.To = new double?(Set);
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) UIElement.OpacityProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(1000);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (DoubleAnimation) null;
    }

    public async void WidthAnimation(
      DependencyObject Object,
      double Get,
      double Set,
      double Duration)
    {
      DoubleAnimation Animation = new DoubleAnimation();
      Animation.EasingFunction = this.Easing;
      Animation.Duration = (Duration) TimeSpan.FromMilliseconds(Duration);
      Animation.From = new double?(Get);
      Animation.To = new double?(Set);
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) FrameworkElement.WidthProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(100);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (DoubleAnimation) null;
    }

    public async void HeightAnimation(
      DependencyObject Object,
      double Get,
      double Set,
      double Duration)
    {
      DoubleAnimation Animation = new DoubleAnimation();
      Animation.EasingFunction = this.Easing;
      Animation.Duration = (Duration) TimeSpan.FromMilliseconds(Duration);
      Animation.From = new double?(Get);
      Animation.To = new double?(Set);
      Storyboard.SetTarget((DependencyObject) Animation, Object);
      Storyboard.SetTargetProperty((DependencyObject) Animation, new PropertyPath((object) FrameworkElement.HeightProperty));
      this.Storyboard.Children.Add((Timeline) Animation);
      this.Storyboard.Begin();
      await Task.Delay(1000);
      this.Storyboard.Children.Remove((Timeline) Animation);
      Animation = (DoubleAnimation) null;
    }

    public void Rotate(RotateTransform Object, double Get, double Set, double Duration)
    {
      DoubleAnimation doubleAnimation = new DoubleAnimation();
      doubleAnimation.From = new double?(Get);
      doubleAnimation.To = new double?(Set);
      doubleAnimation.Duration = (Duration) TimeSpan.FromMilliseconds(Duration);
      doubleAnimation.EasingFunction = this.Easing;
      DoubleAnimation animation = doubleAnimation;
      Object.BeginAnimation(RotateTransform.AngleProperty, (AnimationTimeline) animation, HandoffBehavior.SnapshotAndReplace);
    }

    private IEasingFunction Easing { get; set; }

    public Animation()
    {
      QuadraticEase quadraticEase = new QuadraticEase();
      quadraticEase.EasingMode = EasingMode.EaseInOut;
      // ISSUE: reference to a compiler-generated field
      this.\u003CEasing\u003Ek__BackingField = (IEasingFunction) quadraticEase;
      // ISSUE: explicit constructor call
      base.\u002Ector();
    }
  }
}
