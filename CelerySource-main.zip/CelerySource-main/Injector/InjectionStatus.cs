﻿// Decompiled with JetBrains decompiler
// Type: Injector.InjectionStatus
// Assembly: CeleryApp, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C2BCA464-2E77-4DEE-B9BF-40F89C268B00
// Assembly location: C:\Users\brady\Downloads\Celery\CeleryApp.exe

namespace Injector
{
  public enum InjectionStatus
  {
    FAILED,
    FAILED_ADMINISTRATOR_ACCESS,
    ALREADY_INJECTING,
    ALREADY_INJECTED,
    SUCCESS,
  }
}
