﻿// Decompiled with JetBrains decompiler
// Type: <Module>
// Assembly: CeleryApp, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C2BCA464-2E77-4DEE-B9BF-40F89C268B00
// Assembly location: C:\Users\brady\Downloads\Celery\CeleryApp.exe

using Costura;

internal class \u003CModule\u003E
{
  static \u003CModule\u003E() => AssemblyLoader.Attach();
}
