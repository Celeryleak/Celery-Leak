﻿// Decompiled with JetBrains decompiler
// Type: CeleryApp.Types
// Assembly: CeleryApp, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: C2BCA464-2E77-4DEE-B9BF-40F89C268B00
// Assembly location: C:\Users\brady\Downloads\Celery\CeleryApp.exe

namespace CeleryApp
{
  public enum Types
  {
    Class,
    Color,
    Constructor,
    Enum,
    Field,
    File,
    Folder,
    Function,
    Interface,
    Keyword,
    Method,
    Module,
    Property,
    Reference,
    Snippet,
    Text,
    Unit,
    Value,
    Variable,
    None,
  }
}
